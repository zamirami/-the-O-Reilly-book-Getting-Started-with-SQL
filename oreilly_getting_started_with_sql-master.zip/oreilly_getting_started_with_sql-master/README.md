# Getting Started with SQL

Thank you for reading *Getting Started with SQL*. These are the database files for the book. 

# Having Download Trouble?

This book requires basic proficiency in downloading, unzipping, and navigating files and folders. 

If you need assistance in extracting a zipped folder, [please see this short tutorial](http://www.wikihow.com/Open-a-Zip-File).

For SQLiteStudio, easy-to-use installers are now available so you should not have to unzip/copy/paste SQLiteStudio: https://sqlitestudio.pl/index.rvt?act=download


![](https://images-na.ssl-images-amazon.com/images/I/51A7fbsp0EL.jpg)

